//
// Created by antonio on 08. 12. 2021..
//

#ifndef SPAVJ_CONSTANTS_H
#define SPAVJ_CONSTANTS_H

const int DIGIT_LIMIT = 20;

#endif //SPAVJ_CONSTANTS_H
